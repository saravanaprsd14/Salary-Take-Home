package com.example.takehome

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

enum class Type(val label: String) {
    FIXED("Fixed"), VARIABLE("Variable"), EMPLOYER("Employer-only"), NPS("Employer NPS")
}

class Comp(name: String, amt: Double, type: Type) {
    var name by mutableStateOf(name)
    var amt by mutableStateOf(amt.toLong().toString())
    var type by mutableStateOf(type)
    val value get() = amt.toDoubleOrNull() ?: 0.0
}

class Cfg {
    var newRegime by mutableStateOf(true)
    var varPct by mutableStateOf("100")
    var pfPct by mutableStateOf("12")
    var pt by mutableStateOf("2400")
    var otherMonthly by mutableStateOf("0")
    var oldExtra by mutableStateOf("0")
    var c80 by mutableStateOf("0")
}

fun defaultRows() = listOf(
    Comp("Basic", 442404.0, Type.FIXED), Comp("Food Coupons", 72000.0, Type.FIXED),
    Comp("Gift Coupon", 15000.0, Type.FIXED), Comp("Fuel & Maint Reimb - 4W", 100000.0, Type.FIXED),
    Comp("Broadband Reimbursement", 8400.0, Type.FIXED), Comp("HRA", 427287.0, Type.FIXED),
    Comp("Company Leased Accommodation", 18000.0, Type.FIXED), Comp("Residual Choice Pay", 55433.0, Type.FIXED),
    Comp("National Pension Scheme", 61200.0, Type.NPS), Comp("Provident Fund - Employer", 53088.0, Type.EMPLOYER),
    Comp("Gratuity Contribution", 32133.0, Type.EMPLOYER), Comp("Max Variable Pay", 241428.0, Type.VARIABLE),
    Comp("Medical Insurance", 77868.0, Type.EMPLOYER), Comp("Group Personal Accident", 930.0, Type.EMPLOYER),
    Comp("Group Term Life", 4341.0, Type.EMPLOYER)
)

// ---- Tax (edit slabs here when the Budget changes them) ----
fun incomeTax(taxable: Double, newRegime: Boolean): Double {
    val big = Double.MAX_VALUE
    val slabs = if (newRegime)
        listOf(400000.0 to 0.0, 800000.0 to .05, 1200000.0 to .10, 1600000.0 to .15,
            2000000.0 to .20, 2400000.0 to .25, big to .30)
    else listOf(250000.0 to 0.0, 500000.0 to .05, 1000000.0 to .20, big to .30)
    var tax = 0.0; var prev = 0.0
    for ((limit, rate) in slabs) { if (taxable > prev) tax += (min(taxable, limit) - prev) * rate; prev = limit }
    tax = if (newRegime) { if (taxable <= 1_200_000) 0.0 else min(tax, taxable - 1_200_000) }
    else if (taxable <= 500_000) 0.0 else tax
    return tax * 1.04 // 4% cess
}

class Result(
    val fixed: Double, val variable: Double, val taxable: Double, val tax: Double, val pf: Double,
    val pt: Double, val other: Double, val annualNet: Double, val monthlyFixed: Double
)

fun compute(rows: List<Comp>, c: Cfg): Result {
    fun sum(t: Type) = rows.filter { it.type == t }.sumOf { it.value }
    val fixed = sum(Type.FIXED)
    val variable = sum(Type.VARIABLE) * (c.varPct.toDoubleOrNull() ?: 100.0) / 100
    val nps = sum(Type.NPS)
    val basic = rows.filter { it.name.contains("basic", ignoreCase = true) }.sumOf { it.value }
    val pf = basic * (c.pfPct.toDoubleOrNull() ?: 0.0) / 100
    val pt = c.pt.toDoubleOrNull() ?: 0.0
    val other = (c.otherMonthly.toDoubleOrNull() ?: 0.0) * 12
    val gross = fixed + variable
    var ded = (if (c.newRegime) 75000.0 else 50000.0) + min(nps, basic * if (c.newRegime) .14 else .10)
    if (!c.newRegime) ded += pt + min(150000.0, pf + (c.c80.toDoubleOrNull() ?: 0.0)) + (c.oldExtra.toDoubleOrNull() ?: 0.0)
    val taxable = max(0.0, gross - ded)
    val tax = incomeTax(taxable, c.newRegime)
    val net = gross - pf - pt - tax - other
    val share = if (gross > 0) fixed / gross else 1.0
    return Result(fixed, variable, taxable, tax, pf, pt, other, net, (fixed - pf - pt - tax * share - other) / 12)
}

// ---- Persistence ----
fun save(ctx: Context, rows: List<Comp>, c: Cfg) {
    val arr = JSONArray()
    rows.forEach { arr.put(JSONObject().put("n", it.name).put("a", it.amt).put("t", it.type.name)) }
    val cfg = JSONObject().put("nr", c.newRegime).put("vp", c.varPct).put("pf", c.pfPct).put("pt", c.pt)
        .put("om", c.otherMonthly).put("ox", c.oldExtra).put("c80", c.c80)
    ctx.getSharedPreferences("th", 0).edit().putString("rows", arr.toString()).putString("cfg", cfg.toString()).apply()
}

fun load(ctx: Context, rows: MutableList<Comp>, c: Cfg) {
    val sp = ctx.getSharedPreferences("th", 0)
    val r = sp.getString("rows", null)
    rows.clear()
    if (r == null) { rows.addAll(defaultRows()); return }
    val arr = JSONArray(r)
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        rows.add(Comp(o.getString("n"), o.getString("a").toDoubleOrNull() ?: 0.0, Type.valueOf(o.getString("t"))))
    }
    sp.getString("cfg", null)?.let {
        val o = JSONObject(it)
        c.newRegime = o.getBoolean("nr"); c.varPct = o.getString("vp"); c.pfPct = o.getString("pf")
        c.pt = o.getString("pt"); c.otherMonthly = o.getString("om"); c.oldExtra = o.getString("ox"); c.c80 = o.getString("c80")
    }
}

class MainActivity : ComponentActivity() {
    private val rows = mutableStateListOf<Comp>()
    private val cfg = Cfg()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load(this, rows, cfg)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { Screen(rows, cfg) } } }
    }

    override fun onStop() { super.onStop(); save(this, rows, cfg) }
}

val inr: NumberFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply { maximumFractionDigits = 0 }

@Composable
fun Num(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) =
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = modifier
    )

@Composable
fun Line(label: String, value: String, bold: Boolean = false) =
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), Arrangement.SpaceBetween) {
        Text(label)
        Text(value, fontWeight = if (bold) androidx.compose.ui.text.font.FontWeight.Bold else null)
    }

@Composable
fun Screen(rows: MutableList<Comp>, c: Cfg) {
    val r = compute(rows, c)
    LazyColumn(Modifier.fillMaxSize().systemBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Monthly in-hand (fixed pay)")
                    Text(inr.format(r.monthlyFixed), fontSize = 32.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                    Text("Annual incl. variable: ${inr.format(r.annualNet)}  ·  Avg/month: ${inr.format(r.annualNet / 12)}")
                }
            }
        }
        item { Text("Salary components (annual ₹)", style = MaterialTheme.typography.titleSmall) }
        itemsIndexed(rows) { i, row ->
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(row.name, { row.name = it }, Modifier.weight(1f), singleLine = true)
                    Num("₹", row.amt, { row.amt = it.filter(Char::isDigit) }, Modifier.width(120.dp))
                    IconButton({ rows.removeAt(i) }) { Text("×", fontSize = 22.sp) }
                }
                // tap to cycle: Fixed → Variable → Employer-only → Employer NPS
                TextButton({ row.type = Type.values()[(row.type.ordinal + 1) % Type.values().size] }) {
                    Text("Type: ${row.type.label} (tap to change)")
                }
            }
        }
        item { Button({ rows.add(Comp("New component", 0.0, Type.FIXED)) }) { Text("+ Add component") } }
        item { Text("Settings", style = MaterialTheme.typography.titleSmall) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Old regime", Modifier.padding(end = 8.dp))
                Switch(c.newRegime, { c.newRegime = it })
                Text("New regime", Modifier.padding(start = 8.dp))
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Num("Variable payout %", c.varPct, { c.varPct = it }, Modifier.fillMaxWidth())
                Num("Employee PF % of Basic", c.pfPct, { c.pfPct = it }, Modifier.fillMaxWidth())
                Num("Professional tax / year", c.pt, { c.pt = it }, Modifier.fillMaxWidth())
                Num("Other deductions / month", c.otherMonthly, { c.otherMonthly = it }, Modifier.fillMaxWidth())
                if (!c.newRegime) {
                    Num("80C investments (excl. PF)", c.c80, { c.c80 = it }, Modifier.fillMaxWidth())
                    Num("Other old-regime deductions (HRA exemption, 80D…)", c.oldExtra, { c.oldExtra = it }, Modifier.fillMaxWidth())
                }
            }
        }
        item {
            Card { Column(Modifier.padding(12.dp)) {
                Line("Fixed pay", inr.format(r.fixed))
                Line("Variable (at ${c.varPct}%)", inr.format(r.variable))
                Line("Taxable income", inr.format(r.taxable))
                Line("Income tax + cess", "− " + inr.format(r.tax))
                Line("Employee PF", "− " + inr.format(r.pf))
                Line("Professional tax", "− " + inr.format(r.pt))
                Line("Other deductions", "− " + inr.format(r.other))
                Line("Annual take-home", inr.format(r.annualNet), true)
            } }
        }
        item { Text("Estimate only, not tax advice. Slabs: FY 2026-27 assumed same as FY 2025-26.", fontSize = 12.sp) }
    }
}
